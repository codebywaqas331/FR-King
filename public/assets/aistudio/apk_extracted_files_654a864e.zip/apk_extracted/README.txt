APK EXTRACTION NOTES
====================

This folder contains the files that were directly extractable from base.apk.

Important findings:
- This APK appears to be a Chrome WebAPK / web-app wrapper (the archive contains WebAPK metadata and Google Chrome host classes).
- The APK includes AndroidManifest.xml, resources.arsc, classes.dex, Android resource XML/layout files, launcher/app icons, and signature metadata.
- AndroidManifest.xml and resources.arsc are compiled/binary Android formats, so they may not open as readable XML/text in a normal editor.
- classes.dex contains compiled Dalvik bytecode, not original Java/Kotlin source code.
- No website HTML/CSS/JavaScript source bundle was present as ordinary files in this APK. If the app loads a website, the site's front-end source usually needs to be obtained from the original website/project, not recovered from this wrapper APK.

For readable decompiled output on a computer:
1. Install JADX GUI (for Java-like decompilation of classes.dex).
2. Install APKTool (for decoding Android resources and the manifest).
3. Open base.apk with JADX GUI, or run: jadx -d jadx_output base.apk
4. Decode resources with: apktool d base.apk -o apktool_output

Decompilation cannot guarantee recovery of the original source, comments, names, or project structure.
